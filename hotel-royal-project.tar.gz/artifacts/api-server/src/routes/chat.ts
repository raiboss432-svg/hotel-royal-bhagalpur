import { Router, type IRouter } from "express";
import { SendChatMessageBody, SendChatMessageResponse } from "@workspace/api-zod";

const router: IRouter = Router();

const GROQ_API_KEY = process.env.GROQ_API_KEY || "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";

if (!GROQ_API_KEY) {
  throw new Error("GROQ_API_KEY is not set");
}
const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const MODEL = "llama-3.1-8b-instant";

const SYSTEM_PROMPT = `You are the official AI Assistant for Hotel Royal. Answer politely, concisely, and strictly based on the following details. If a user asks for something not listed, politely decline.
Hotel Info: Hotel Royal Bhagalpur, Station Road, City Center. Manager: Mr. Vikram Singh (+91-98765-43210).
Rooms: Standard AC (₹1500/night), Premium River View (₹2500/night), Royal Suite (₹4500/night). Check-in: 12 PM, Check-out: 11 AM.
Veg Menu: Paneer Butter Masala (₹250), Dal Makhani (₹180), Veg Pulao (₹150), Tandoori Roti (₹20).
Non-Veg Menu: Chicken Dum Biryani (₹300), Mutton Rogan Josh (₹400), Fish Curry (₹350).
Drinks: Fresh Lime Soda (₹60), Cold Coffee (₹90), Mango Lassi (₹80).
Services: Free 24/7 Wi-Fi, Laundry (₹50/pair), Pick & Drop Cab Service, Free Rooftop Pool (6 AM-8 PM).
Rules: No smoking in rooms, Couple friendly with valid Govt ID.`;

router.post("/chat", async (req, res) => {
  try {
    const parsed = SendChatMessageBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Invalid request body" });
      return;
    }

    const { message, history = [] } = parsed.data;

    const messages = [
      { role: "system", content: SYSTEM_PROMPT },
      ...history.map((h) => ({ role: h.role, content: h.content })),
      { role: "user", content: message },
    ];

    const response = await fetch(GROQ_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model: MODEL,
        messages,
        max_tokens: 512,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Groq API error:", response.status, errorText);
      res.status(500).json({ error: "Failed to get AI response" });
      return;
    }

    const data = (await response.json()) as {
      choices: { message: { content: string } }[];
    };

    const reply = data.choices?.[0]?.message?.content ?? "I'm sorry, I couldn't process your request.";

    const result = SendChatMessageResponse.parse({ reply });
    res.json(result);
  } catch (err) {
    console.error("Chat route error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
