import { Navbar } from "@/components/Navbar";
import { HeroSection } from "@/components/sections/HeroSection";
import { RoomsSection } from "@/components/sections/RoomsSection";
import { MenuSection } from "@/components/sections/MenuSection";
import { ServicesSection } from "@/components/sections/ServicesSection";
import { ContactSection } from "@/components/sections/ContactSection";
import { Footer } from "@/components/Footer";
import { ChatWidget } from "@/components/ChatWidget";

export default function Home() {
  return (
    <div className="min-h-screen w-full bg-background text-foreground overflow-x-hidden">
      <Navbar />
      
      <main>
        <HeroSection />
        <RoomsSection />
        <MenuSection />
        <ServicesSection />
        <ContactSection />
      </main>

      <Footer />
      
      {/* Floating AI Assistant */}
      <ChatWidget />
    </div>
  );
}
