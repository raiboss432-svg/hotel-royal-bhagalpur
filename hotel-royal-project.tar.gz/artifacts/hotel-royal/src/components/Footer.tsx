export function Footer() {
  return (
    <footer className="bg-background py-12 border-t border-white/10 text-center">
      <div className="container mx-auto px-4 flex flex-col items-center">
        <img 
          src={`${import.meta.env.BASE_URL}images/logo.png`} 
          alt="Hotel Royal Logo" 
          className="w-16 h-16 object-contain mb-6 opacity-80"
        />
        <h2 className="font-display text-2xl font-bold text-white mb-2 uppercase tracking-widest">Hotel Royal</h2>
        <p className="text-muted-foreground text-sm tracking-wider uppercase mb-8">Bhagalpur</p>
        
        <div className="h-[1px] w-24 bg-primary/30 mb-8"></div>
        
        <p className="text-white/40 text-sm">
          &copy; {new Date().getFullYear()} Hotel Royal Bhagalpur. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
