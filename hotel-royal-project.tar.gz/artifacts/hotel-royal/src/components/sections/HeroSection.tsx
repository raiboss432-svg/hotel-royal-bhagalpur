import { motion } from "framer-motion";
import { useIntersection } from "@/hooks/use-intersection";

export function HeroSection() {
  const { ref, visible } = useIntersection();

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image & Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1920&q=80" 
          alt="Luxury Hotel Lobby" 
          className="w-full h-full object-cover"
        />
        {/* Dark elegant gradient overlay */}
        <div className="absolute inset-0 hero-overlay" />
      </div>

      {/* Content */}
      <div ref={ref} className={`relative z-10 container mx-auto px-4 md:px-8 text-center flex flex-col items-center fade-in ${visible ? 'visible' : ''}`}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="mb-6 flex flex-col items-center w-full"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="h-[1px] w-12 bg-primary"></div>
            <span className="text-primary tracking-[0.3em] uppercase text-sm font-semibold">Welcome To</span>
            <div className="h-[1px] w-12 bg-primary"></div>
          </div>
          
          <h1 className="font-display text-4xl md:text-6xl lg:text-8xl font-bold text-white leading-tight drop-shadow-2xl text-shadow-glow">
            Hotel Royal
          </h1>
          <p className="font-sans text-lg md:text-2xl text-white/80 tracking-[0.2em] font-light mt-4 uppercase">
            Bhagalpur
          </p>
          <div className="gold-divider" />
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="max-w-2xl text-muted-foreground text-base md:text-lg mb-10 leading-relaxed px-4"
        >
          Experience unparalleled luxury and impeccable service in the heart of the city. 
          A sanctuary of elegance designed for the modern traveler.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto"
        >
          <a 
            href="#rooms" 
            className="bg-amber-500 text-blue-950 font-semibold hover:bg-amber-400 hover:shadow-[0_0_20px_rgba(212,175,55,0.6)] hover:scale-105 transition-all duration-300 px-8 py-4 rounded-full tracking-widest uppercase text-sm w-full sm:w-auto min-h-[44px] flex items-center justify-center"
          >
            Reserve Your Stay
          </a>
          <a 
            href="#services" 
            className="px-8 py-4 bg-transparent border border-white/20 text-white font-semibold tracking-widest uppercase text-sm rounded-full hover:bg-white/10 transition-all duration-300 backdrop-blur-sm w-full sm:w-auto min-h-[44px] flex items-center justify-center"
          >
            Explore Amenities
          </a>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-[10px] uppercase tracking-widest text-white/50">Scroll</span>
        <div className="w-[1px] h-12 bg-white/20 relative overflow-hidden">
          <motion.div 
            animate={{ top: ['-100%', '100%'] }}
            transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
            className="absolute left-0 right-0 w-full h-1/2 bg-primary"
          />
        </div>
      </motion.div>
    </section>
  );
}
