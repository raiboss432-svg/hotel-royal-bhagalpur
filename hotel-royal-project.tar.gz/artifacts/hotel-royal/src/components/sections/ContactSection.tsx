import { useState } from "react";
import { motion } from "framer-motion";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useIntersection } from "@/hooks/use-intersection";

export function ContactSection() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { ref, visible } = useIntersection();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      toast({
        title: "Message Sent Successfully",
        description: "Our concierge team will get back to you shortly.",
        variant: "default",
      });
      (e.target as HTMLFormElement).reset();
    }, 1500);
  };

  return (
    <section id="contact" className="py-24 bg-card relative border-t border-white/5">
      <div ref={ref} className={`container mx-auto px-4 md:px-8 fade-in ${visible ? 'visible' : ''}`}>
        
        <div className="text-center mb-16">
          <span className="text-primary tracking-[0.2em] uppercase text-sm font-semibold block mb-3">Get In Touch</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-2">Contact Us</h2>
          <div className="gold-divider" />
        </div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-24 max-w-6xl mx-auto">
          
          {/* Contact Details */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="font-display text-2xl font-bold text-white mb-8">Location & Information</h3>
            
            <div className="space-y-8">
              <div className="flex gap-4">
                <div className="w-12 h-12 shrink-0 rounded-full bg-background flex items-center justify-center text-primary border border-white/5">
                  <MapPin size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-white mb-1">Address</h4>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Station Road, City Center<br />
                    Bhagalpur, Bihar<br />
                    India
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 shrink-0 rounded-full bg-background flex items-center justify-center text-primary border border-white/5">
                  <Phone size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-white mb-1">Manager: Mr. Vikram Singh</h4>
                  <p className="text-muted-foreground text-sm">
                    <a href="tel:+919876543210" className="hover:text-primary transition-colors min-h-[44px] flex items-center">+91 98765 43210</a>
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 shrink-0 rounded-full bg-background flex items-center justify-center text-primary border border-white/5">
                  <Clock size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-white mb-1">Front Desk Hours</h4>
                  <p className="text-muted-foreground text-sm">
                    24/7 Availability for our esteemed guests.
                  </p>
                </div>
              </div>
            </div>

            {/* A styled placeholder for a map */}
            <div className="mt-12 h-48 rounded-xl overflow-hidden border border-white/10 relative group">
              <img 
                src="https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=2074&auto=format&fit=crop" 
                alt="Map context" 
                className="w-full h-full object-cover opacity-50 mix-blend-luminosity"
              />
              <div className="absolute inset-0 bg-background/50 flex items-center justify-center group-hover:bg-background/40 transition-colors">
                <div className="px-4 py-2 bg-background/80 backdrop-blur-sm border border-white/10 rounded-full flex items-center gap-2 text-sm text-white min-h-[44px]">
                  <MapPin size={14} className="text-primary"/> View on Maps
                </div>
              </div>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-background p-8 lg:p-10 rounded-2xl border border-white/5 shadow-2xl relative"
          >
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50"></div>
            <h3 className="font-display text-2xl font-bold text-white mb-8">Send an Inquiry</h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-white/70 mb-2">Full Name</label>
                <input 
                  type="text" 
                  id="name" 
                  required
                  className="w-full bg-card border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all min-h-[44px]"
                  placeholder="John Doe"
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-white/70 mb-2">Email Address</label>
                <input 
                  type="email" 
                  id="email" 
                  required
                  className="w-full bg-card border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all min-h-[44px]"
                  placeholder="john@example.com"
                />
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-white/70 mb-2">Message or Special Request</label>
                <textarea 
                  id="message" 
                  required
                  rows={4}
                  className="w-full bg-card border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all resize-none"
                  placeholder="How can we make your stay more comfortable?"
                ></textarea>
              </div>
              
              <button 
                type="submit" 
                disabled={isSubmitting}
                className="w-full bg-amber-500 text-blue-950 font-semibold hover:bg-amber-400 hover:shadow-[0_0_20px_rgba(212,175,55,0.6)] hover:scale-[1.02] transition-all duration-300 px-6 py-3.5 rounded-full tracking-widest uppercase text-sm disabled:opacity-70 min-h-[44px]"
              >
                {isSubmitting ? "Sending..." : "Send Message"}
              </button>
            </form>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
