import { motion } from "framer-motion";
import { Check, Info } from "lucide-react";
import { useIntersection } from "@/hooks/use-intersection";

const ROOMS = [
  {
    id: "standard",
    name: "Standard AC",
    price: "1,500",
    image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800&q=80",
    features: ["Queen Size Bed", "Air Conditioning", "City View", "Free Wi-Fi", "En-suite Bathroom"],
    description: "Comfortable and cozy, perfect for short business trips or solo travelers."
  },
  {
    id: "premium",
    name: "Premium River View",
    price: "2,500",
    image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800&q=80",
    features: ["King Size Bed", "Panoramic River View", "Mini Bar", "Premium Toiletries", "Workspace"],
    description: "Wake up to breathtaking views of the river in our spacious premium accommodation."
  },
  {
    id: "royal",
    name: "Royal Suite",
    price: "4,500",
    image: "https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800&q=80",
    features: ["Master Bedroom & Living Area", "Jacuzzi", "Complimentary Breakfast", "Butler Service", "Exclusive Access"],
    description: "The epitome of luxury. Expansive spaces adorned with elegant furnishings and premium amenities."
  }
];

export function RoomsSection() {
  const { ref, visible } = useIntersection();

  return (
    <section id="rooms" className="py-24 bg-background relative border-t border-white/5">
      <div ref={ref} className={`container mx-auto px-4 md:px-8 fade-in ${visible ? 'visible' : ''}`}>
        <div className="text-center mb-16">
          <span className="text-primary tracking-[0.2em] uppercase text-sm font-semibold block mb-3">Accommodations</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-2">Rooms & Suites</h2>
          <div className="gold-divider" />
          <p className="max-w-2xl mx-auto text-muted-foreground mt-6">
            Each of our rooms is meticulously designed to provide an oasis of comfort and style, ensuring a restful and rejuvenating stay.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 md:gap-6 mt-8 text-sm text-white/60">
            <span className="flex items-center gap-2"><Info size={16} className="text-primary"/> Check-in: 12:00 PM</span>
            <span className="flex items-center gap-2"><Info size={16} className="text-primary"/> Check-out: 11:00 AM</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {ROOMS.map((room, index) => (
            <motion.div
              key={room.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="group bg-card rounded-xl overflow-hidden border border-white/5 hover:border-primary/30 transition-all duration-500 hover:shadow-[0_10px_40px_-10px_rgba(0,0,0,0.5)] flex flex-col"
            >
              <div className="relative h-64 overflow-hidden shrink-0">
                <img 
                  src={room.image} 
                  alt={room.name} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent opacity-80" />
                <div className="absolute bottom-4 left-6">
                  <h3 className="font-display text-2xl font-bold text-white">{room.name}</h3>
                </div>
              </div>
              
              <div className="p-6 flex flex-col flex-1">
                <div className="flex items-end gap-1 mb-4">
                  <span className="text-3xl font-bold text-primary">₹{room.price}</span>
                  <span className="text-sm text-muted-foreground pb-1">/ night</span>
                </div>
                
                <p className="text-muted-foreground text-sm mb-6 min-h-[40px]">
                  {room.description}
                </p>
                
                <ul className="space-y-2 mb-8 flex-1">
                  {room.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-white/80">
                      <Check size={16} className="text-primary shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <button 
                  className="w-full bg-amber-500 text-blue-950 font-semibold hover:bg-amber-400 hover:shadow-[0_0_20px_rgba(212,175,55,0.6)] hover:scale-[1.02] transition-all duration-300 px-6 py-3.5 rounded-full mt-auto tracking-widest uppercase text-sm min-h-[44px]"
                  onClick={() => window.location.hash = "contact"}
                >
                  Book Room
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
