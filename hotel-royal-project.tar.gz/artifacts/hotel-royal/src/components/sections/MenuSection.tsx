import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useIntersection } from "@/hooks/use-intersection";

type Category = "veg" | "non-veg" | "drinks";

const MENU_DATA = {
  "veg": [
    { name: "Paneer Butter Masala", price: "250", desc: "Cottage cheese cooked in a rich, creamy tomato gravy." },
    { name: "Dal Makhani", price: "180", desc: "Black lentils simmered overnight with butter and cream." },
    { name: "Veg Pulao", price: "150", desc: "Aromatic basmati rice cooked with mixed vegetables and spices." },
    { name: "Tandoori Roti", price: "20", desc: "Traditional Indian bread baked in a clay oven." },
  ],
  "non-veg": [
    { name: "Chicken Dum Biryani", price: "300", desc: "Fragrant basmati rice layered with marinated chicken and cooked to perfection." },
    { name: "Mutton Rogan Josh", price: "400", desc: "Tender lamb pieces simmered in a robust, aromatic Kashmiri gravy." },
    { name: "Fish Curry", price: "350", desc: "Fresh river fish cooked in a tangy mustard and coconut sauce." },
  ],
  "drinks": [
    { name: "Fresh Lime Soda", price: "60", desc: "Refreshing citrus beverage served sweet or salted." },
    { name: "Cold Coffee", price: "90", desc: "Creamy, chilled blended coffee topped with chocolate dusting." },
    { name: "Mango Lassi", price: "80", desc: "Traditional sweet yogurt drink blended with fresh mango puree." },
  ]
};

export function MenuSection() {
  const [activeCategory, setActiveCategory] = useState<Category>("veg");
  const { ref, visible } = useIntersection();

  return (
    <section id="menu" className="py-24 bg-card relative">
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at center, white 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
      
      <div ref={ref} className={`container mx-auto px-4 md:px-8 relative z-10 fade-in ${visible ? 'visible' : ''}`}>
        <div className="text-center mb-16">
          <span className="text-primary tracking-[0.2em] uppercase text-sm font-semibold block mb-3">Culinary Experience</span>
          <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-2">Royal Dining</h2>
          <div className="gold-divider" />
          <p className="max-w-2xl mx-auto text-muted-foreground mt-6">
            Savor the exquisite flavors of our master chefs. From traditional local delicacies to international favorites, our menu is crafted to delight.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex justify-center mb-12">
          <div className="inline-flex p-1 bg-background rounded-full border border-white/10 overflow-x-auto max-w-full hide-scrollbar">
            {(["veg", "non-veg", "drinks"] as const).map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`
                  relative px-6 py-3 text-sm font-medium tracking-wider uppercase rounded-full transition-all duration-300 whitespace-nowrap min-h-[44px]
                  ${activeCategory === category ? 'text-primary-foreground' : 'text-white/60 hover:text-white'}
                `}
              >
                {activeCategory === category && (
                  <motion.div 
                    layoutId="menu-tab-indicator"
                    className="absolute inset-0 bg-primary rounded-full shadow-md"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
                <span className="relative z-10">
                  {category.replace('-', ' ')}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Menu Items Grid */}
        <div className="max-w-4xl mx-auto min-h-[400px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8"
            >
              {MENU_DATA[activeCategory].map((item, index) => (
                <div key={index} className="flex flex-col border-b border-white/5 pb-6 w-full">
                  <div className="flex justify-between items-baseline mb-2 gap-4">
                    <h4 className="font-display text-xl font-bold text-white shrink-0">{item.name}</h4>
                    <div className="hidden sm:block flex-1 border-b border-dashed border-white/20 relative top-[-4px]"></div>
                    <span className="font-bold text-primary whitespace-nowrap ml-auto sm:ml-0">₹{item.price}</span>
                  </div>
                  <p className="text-muted-foreground text-sm font-light leading-relaxed md:pr-12">
                    {item.desc}
                  </p>
                </div>
              ))}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
