import { motion } from "framer-motion";
import { Wifi, Waves, Car, Wind } from "lucide-react";
import { useIntersection } from "@/hooks/use-intersection";

const SERVICES = [
  {
    icon: <Wifi size={32} />,
    title: "Free 24/7 Wi-Fi",
    description: "Stay connected with high-speed internet access available throughout the hotel premises, perfectly suited for business and leisure."
  },
  {
    icon: <Wind size={32} />,
    title: "Premium Laundry",
    description: "Impeccable laundry and dry-cleaning services delivered promptly. (₹50/pair)"
  },
  {
    icon: <Car size={32} />,
    title: "Pick & Drop Cab",
    description: "Hassle-free transportation with our dedicated chauffeur-driven luxury fleet available upon request."
  },
  {
    icon: <Waves size={32} />,
    title: "Rooftop Pool",
    description: "Unwind in our stunning rooftop infinity pool offering panoramic city views. Complimentary access from 6 AM to 8 PM."
  }
];

export function ServicesSection() {
  const { ref, visible } = useIntersection();

  return (
    <section id="services" className="py-24 bg-background border-t border-white/5 relative overflow-hidden">
      {/* decorative background element */}
      <div className="absolute inset-0 z-0 opacity-10">
        <img src="https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=1200&q=80" alt="Spa and Amenities" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-background/80" />
      </div>
      <div className="absolute top-0 right-0 w-1/3 h-full bg-primary/5 blur-[150px] rounded-full pointer-events-none transform translate-x-1/2"></div>
      
      <div ref={ref} className={`container mx-auto px-4 md:px-8 relative z-10 fade-in ${visible ? 'visible' : ''}`}>
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-16 items-center">
          
          <div className="w-full lg:w-1/3 text-center lg:text-left">
            <span className="text-primary tracking-[0.2em] uppercase text-sm font-semibold block mb-3">Amenities</span>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-white mb-2 leading-tight">Beyond Expectation</h2>
            <div className="gold-divider lg:ml-0" />
            <p className="text-muted-foreground mb-8 mt-6">
              We anticipate your every need. Our comprehensive range of services ensures that your stay is not just comfortable, but truly extraordinary.
            </p>
            <div className="p-5 border border-primary/20 bg-primary/5 rounded-lg text-left inline-block w-full">
              <h4 className="font-display font-bold text-white mb-2 text-lg">Hotel Policies</h4>
              <ul className="text-sm text-white/70 space-y-2">
                <li className="flex items-center gap-2">• Strictly non-smoking rooms</li>
                <li className="flex items-center gap-2">• Couple friendly (Valid Govt ID required)</li>
              </ul>
            </div>
          </div>

          <div className="w-full lg:w-2/3 grid grid-cols-1 sm:grid-cols-2 gap-6">
            {SERVICES.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-card/90 backdrop-blur-sm p-8 rounded-xl border border-white/5 hover:border-primary/30 transition-all duration-300 group shadow-lg"
              >
                <div className="w-14 h-14 rounded-lg bg-background flex items-center justify-center text-primary mb-6 group-hover:scale-110 group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300 shadow-md">
                  {service.icon}
                </div>
                <h3 className="font-display text-xl font-bold text-white mb-3">{service.title}</h3>
                <p className="text-muted-foreground text-sm font-light leading-relaxed">
                  {service.description}
                </p>
              </motion.div>
            ))}
          </div>

        </div>
      </div>
    </section>
  );
}
