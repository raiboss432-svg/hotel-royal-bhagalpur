import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

const NAV_LINKS = [
  { name: "Home", href: "#home" },
  { name: "Rooms & Suites", href: "#rooms" },
  { name: "Dining", href: "#menu" },
  { name: "Amenities", href: "#services" },
  { name: "Contact", href: "#contact" },
];

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 inset-x-0 z-50 transition-all duration-300 ease-in-out border-b border-transparent",
        isScrolled
          ? "bg-background/90 backdrop-blur-md border-border/50 py-3 shadow-lg"
          : "bg-transparent py-5"
      )}
    >
      <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        {/* Logo */}
        <a href="#home" className="flex items-center gap-3 group">
          <img 
            src={`${import.meta.env.BASE_URL}images/logo.png`} 
            alt="Hotel Royal Logo" 
            className="w-10 h-10 object-contain group-hover:scale-105 transition-transform duration-300"
          />
          <div className="flex flex-col">
            <span className="font-display text-2xl font-bold text-primary leading-none uppercase tracking-widest">
              Hotel Royal
            </span>
            <span className="text-[0.6rem] uppercase tracking-[0.3em] text-muted-foreground ml-0.5">
              Bhagalpur
            </span>
          </div>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-sm font-medium text-foreground/80 hover:text-primary transition-colors duration-200 uppercase tracking-widest relative group"
            >
              {link.name}
              <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-primary transition-all duration-300 group-hover:w-full"></span>
            </a>
          ))}
          <a
            href="#rooms"
            className="px-6 py-2.5 bg-amber-500 text-blue-950 font-semibold text-sm uppercase tracking-wider rounded-full hover:bg-amber-400 hover:shadow-[0_0_20px_rgba(212,175,55,0.6)] hover:scale-105 transition-all duration-300"
          >
            Book Now
          </a>
        </nav>

        {/* Mobile Toggle */}
        <button
          className="md:hidden p-2 text-foreground hover:text-primary transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-background/95 backdrop-blur-xl border-b border-border/50 overflow-hidden"
          >
            <nav className="flex flex-col px-6 py-8 gap-6 items-center">
              {NAV_LINKS.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-lg font-display tracking-widest uppercase text-foreground hover:text-primary transition-colors min-h-[44px] flex items-center justify-center w-full"
                >
                  {link.name}
                </a>
              ))}
              <a
                href="#rooms"
                onClick={() => setMobileMenuOpen(false)}
                className="mt-4 px-8 py-3 bg-amber-500 text-blue-950 font-bold tracking-widest uppercase text-sm rounded-full hover:bg-amber-400 hover:shadow-[0_0_20px_rgba(212,175,55,0.6)] hover:scale-105 transition-all duration-300"
              >
                Book Now
              </a>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
