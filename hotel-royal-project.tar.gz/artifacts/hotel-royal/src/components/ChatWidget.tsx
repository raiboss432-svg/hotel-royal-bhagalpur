import { useState } from "react";
import { X, Send, MessageCircle } from "lucide-react";
import { useChat } from "@/hooks/use-chat";
import { cn } from "@/lib/utils";

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const { messages, input, setInput, handleSend, isPending, messagesEndRef } = useChat();

  return (
    <>
      {/* Floating Gold Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          aria-label="Open AI Assistant"
          className="fixed bottom-6 right-6 z-[9999] w-16 h-16 rounded-full flex items-center justify-center cursor-pointer"
          style={{
            background: "linear-gradient(135deg, #f5c842, #d4a017)",
            boxShadow: "0 0 24px rgba(212,160,23,0.6), 0 4px 20px rgba(0,0,0,0.4)",
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLButtonElement).style.transform = "scale(1.1)";
            (e.currentTarget as HTMLButtonElement).style.boxShadow =
              "0 0 36px rgba(212,160,23,0.85), 0 4px 24px rgba(0,0,0,0.5)";
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLButtonElement).style.transform = "scale(1)";
            (e.currentTarget as HTMLButtonElement).style.boxShadow =
              "0 0 24px rgba(212,160,23,0.6), 0 4px 20px rgba(0,0,0,0.4)";
          }}
        >
          <MessageCircle size={28} color="#0f1c3f" strokeWidth={2.2} />
          {/* Online green dot */}
          <span
            className="absolute top-1 right-1 w-3.5 h-3.5 rounded-full bg-green-400 border-2 border-[#0f1c3f]"
            style={{ animation: "pulse 2s infinite" }}
          />
        </button>
      )}

      {/* Chat Panel */}
      {isOpen && (
        <div
          className="fixed bottom-6 right-6 z-[9999] flex flex-col rounded-2xl overflow-hidden"
          style={{
            width: "min(360px, calc(100vw - 2rem))",
            height: "min(520px, calc(100vh - 5rem))",
            boxShadow: "0 0 40px rgba(212,160,23,0.3), 0 20px 60px rgba(0,0,0,0.6)",
            border: "1px solid rgba(212,160,23,0.3)",
            background: "#0a1228",
          }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-5 py-4 shrink-0"
            style={{
              background: "linear-gradient(135deg, #0f1c3f, #1a2d5a)",
              borderBottom: "1px solid rgba(212,160,23,0.3)",
            }}
          >
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center text-lg shrink-0"
                style={{ background: "linear-gradient(135deg, #f5c842, #d4a017)" }}
              >
                🏨
              </div>
              <div>
                <h3 className="font-bold text-white text-base leading-tight">Royal Concierge</h3>
                <p className="text-xs font-medium" style={{ color: "#f5c842" }}>
                  ● Online — AI Assistant
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="w-8 h-8 rounded-full flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Close"
            >
              <X size={18} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3" style={{ background: "#0a1228" }}>
            {messages.map((msg, i) => (
              <div
                key={i}
                className={cn("flex", msg.role === "user" ? "justify-end" : "justify-start")}
              >
                <div
                  className={cn(
                    "max-w-[80%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed",
                    msg.role === "user"
                      ? "rounded-tr-sm text-[#0f1c3f] font-medium"
                      : "rounded-tl-sm text-white/90"
                  )}
                  style={
                    msg.role === "user"
                      ? { background: "linear-gradient(135deg, #f5c842, #d4a017)" }
                      : { background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.1)" }
                  }
                >
                  {msg.content}
                </div>
              </div>
            ))}

            {isPending && (
              <div className="flex justify-start">
                <div
                  className="px-5 py-3 rounded-2xl rounded-tl-sm flex items-center gap-1.5"
                  style={{ background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.1)" }}
                >
                  {[0, 1, 2].map((i) => (
                    <span
                      key={i}
                      className="w-2 h-2 rounded-full"
                      style={{
                        background: "#f5c842",
                        animation: `bounce 1.2s ${i * 0.2}s infinite`,
                      }}
                    />
                  ))}
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <form
            onSubmit={handleSend}
            className="shrink-0 flex items-center gap-2 p-4"
            style={{
              background: "rgba(15,28,63,0.95)",
              borderTop: "1px solid rgba(212,160,23,0.2)",
            }}
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about rooms, menu, services..."
              disabled={isPending}
              className="flex-1 text-sm text-white placeholder-white/40 bg-transparent outline-none px-4 py-2.5 rounded-xl"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(212,160,23,0.25)",
              }}
              onFocus={(e) => {
                e.currentTarget.style.border = "1px solid rgba(212,160,23,0.7)";
              }}
              onBlur={(e) => {
                e.currentTarget.style.border = "1px solid rgba(212,160,23,0.25)";
              }}
            />
            <button
              type="submit"
              disabled={!input.trim() || isPending}
              className="w-11 h-11 shrink-0 rounded-xl flex items-center justify-center disabled:opacity-40 disabled:cursor-not-allowed transition-all"
              style={{ background: "linear-gradient(135deg, #f5c842, #d4a017)" }}
            >
              <Send size={18} color="#0f1c3f" strokeWidth={2.2} />
            </button>
          </form>
        </div>
      )}

      <style>{`
        @keyframes bounce {
          0%, 60%, 100% { transform: translateY(0); opacity: 0.6; }
          30% { transform: translateY(-6px); opacity: 1; }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>
    </>
  );
}
